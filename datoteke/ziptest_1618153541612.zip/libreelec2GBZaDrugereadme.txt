Za konfiguraciju 

SSH 	root libreelec12
SFTP 	root libreelec12 port 22

PORTAINER(docker) 	http://192.168.1.115:9000	admin	adminadmin
TORRENT 		http://192.168.1.115:9091	root root
MYSQL(mariadb)		root root (kodi kodi)

SAMBA
	\\192.168.1.115
	
	kofigurirati tako da se obri�e sample file te se uredi

	OBRISATI 	\\192.168.1.115\Configfiles\samba.conf.sample - on se uvijek stvori nakon restarta ali obrisati ga te urediti
	UERDITI 	\\192.168.1.115\Configfiles\samba.conf po �elji
	
KODI SUCELJE i podaci
	http://192.168.1.115:8080 osmc osmc

DOCKER mogu�nosti
	/storage/alen/php
	/storage/alen/node
	
	-potrebno u dockeru preuzeti apache i php image-container te postaviti da gleda /storage/alen/php kao u containeru /var/www/html/
	-isto tako node te postaviti da gleda node u /storage/alen/node radi lak�eg uploada i testiranja
	
chmod -R 777 <putanja datoteke sve rekurzivno>
chmod -R 777 /storage/alen/
chmod -R 777 /storage/emulators/